import { useState, useRef, useEffect } from 'react';
import './App.css';
import axios from 'axios';
import { Mic } from 'lucide-react';

function App() {
  const [question, setQuestion] = useState("");
  const [chatHistory, setChatHistory] = useState([]);
  const [isRecording, setIsRecording] = useState(false);
  const [showTooltip, setShowTooltip] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const chatEndRef = useRef(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory]);

  function cleanBotResponse(text) {
    const patternsToRemove = [
      /i\s*(am|'m)?\s*not\s*(a\s*)?(real\s*)?(doctor|medical\s*professional)[^.!?]*[.!?]/gi,
      /this\s+is\s+not\s+medical\s+advice[^.!?]*[.!?]/gi,
      /i\s+can't\s+give\s+medical\s+advice[^.!?]*[.!?]/gi,
      /you\s+should\s+consult\s+(a\s*)?(doctor|healthcare\s*provider)[^.!?]*[.!?]/gi,
      /it's\s+always\s+a\s+good\s+idea\s+to\s+consult[^.!?]*[.!?]/gi,
      /if\s+you'?re\s+concerned[^.!?]*[.!?]/gi,
    ];

    let cleaned = text;
    for (const pattern of patternsToRemove) {
      cleaned = cleaned.replace(pattern, '');
    }

    return cleaned.trim();
  }

  function formatTextToHTML(text) {
    const lines = text.split('\n');
    let formatted = '';
    let inList = false;
    let isOrderedList = false;

    const closeList = () => {
      if (inList) {
        formatted += isOrderedList ? '</ol>' : '</ul>';
        inList = false;
      }
    };

    for (let line of lines) {
      const trimmed = line.trim();
      if (trimmed === '') {
        closeList();
        formatted += '<br>';
        continue;
      }

      const boldLine = line.match(/^\*\*(.*?)\*\*:?$/);
      if (boldLine) {
        closeList();
        formatted += `<p><strong>${boldLine[1]}:</strong></p>`;
        continue;
      }

      if (/^\d+\.\s+/.test(trimmed)) {
        if (!inList || !isOrderedList) {
          closeList();
          formatted += '<ol style="padding-left:1.5rem;">';
          inList = true;
          isOrderedList = true;
        }
        formatted += `<li>${trimmed.replace(/^\d+\.\s+/, '')}</li>`;
      } else if (/^[-*]\s+/.test(trimmed)) {
        if (!inList || isOrderedList) {
          closeList();
          formatted += '<ul style="padding-left:1.5rem;">';
          inList = true;
          isOrderedList = false;
        }
        let item = trimmed.replace(/^[-*]\s+/, '');
        item = item.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        formatted += `<li style="margin-bottom:0.5rem;">${item}</li>`;
      } else {
        closeList();
        const paragraph = line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        formatted += `<p>${paragraph}</p>`;
      }
    }

    closeList();
    return formatted;
  }

  async function generateAnswer(prompt = question) {
    if (!prompt.trim()) return;
    setQuestion("");
    setIsLoading(true);
    setChatHistory(prev => [...prev, { role: 'user', content: prompt }]);

    const response = await axios({
      url: "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=AIzaSyAqOLUSwXfb6I3o9yyASOSdbsGhTUtAEIM",
      method: "post",
      data: {
        contents: [{ parts: [{ text: prompt }] }]
      }
    });

    const rawText = response.data.candidates[0].content.parts[0].text;
    const cleaned = cleanBotResponse(rawText);
    const formatted = formatTextToHTML(cleaned);
    setIsLoading(false);
    setChatHistory(prev => [...prev, { role: 'bot', content: formatted }]);
  }

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      generateAnswer();
    }
  };

  const startVoiceInput = () => {
    const recognition = new window.webkitSpeechRecognition();
    recognition.lang = 'en-US';
    setIsRecording(true);
    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setQuestion(transcript);
      setIsRecording(false);
    };
    recognition.onend = () => setIsRecording(false);
    recognition.onerror = () => setIsRecording(false);
    recognition.start();
  };

  const suggestions = [
    "What are some home remedies for a cold?",
    "How can I improve my sleep quality?",
    "What should I eat to boost my immunity?",
    "How do I treat a sore throat naturally?",
    "When should I see a doctor for a headache?"
  ];

  return (
    <div style={{ width: '100vw', height: '100vh', background: 'linear-gradient(to right, #f3e8ff, #bfdbfe)', display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Health Chat AI</h1>

      <div className="chat-box">
        {chatHistory.length === 0 ? (
          <div className="suggestions">
            <p><strong>💡 Try asking:</strong></p>
            <ul>
              {suggestions.map((item, idx) => (
                <li key={idx}>
                  <button onClick={() => generateAnswer(item)} className="suggestionBtn">
                    {item}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        ) : (
          chatHistory.map((msg, index) => (
            <div
              key={index}
              className="message"
              style={{
                alignSelf: msg.role === 'user' ? 'flex-end' : 'flex-start',
                backgroundColor: msg.role === 'user' ? '#dbeafe' : '#f3f4f6',
              }}
            >
              <div className="message-text" dangerouslySetInnerHTML={{ __html: msg.content }}></div>
            </div>
          ))
        )}

        {isLoading && (
          <div className="message" style={{ alignSelf: 'flex-start', backgroundColor: '#f3f4f6' }}>
            <div className="loading-dots">
              <span>.</span><span>.</span><span>.</span>
            </div>
          </div>
        )}

        <div ref={chatEndRef} />
      </div>

      <div className="input-row">
        <textarea
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          onKeyDown={handleKeyDown}
          rows="1"
          placeholder="Type your health question..."
        ></textarea>

        <div
          onClick={startVoiceInput}
          onMouseEnter={() => setShowTooltip(true)}
          onMouseLeave={() => setShowTooltip(false)}
          className={isRecording ? "mic-animate" : ""}
          style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', position: 'relative', padding: '0.3rem' }}
        >
          <Mic size={24} color="#7c3aed" />
          {showTooltip && <div className="tooltip">Start Voice Input</div>}
        </div>

        <button onClick={generateAnswer} className="send">➤</button>
      </div>
    </div>
  );
}

export default App;